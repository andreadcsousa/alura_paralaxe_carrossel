import { Carousel } from "./carousel.js"

new Carousel()
