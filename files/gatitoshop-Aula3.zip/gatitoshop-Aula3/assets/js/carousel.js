export class Carousel {
    constructor() {
        console.log("Carousel criado com sucesso!!!")
    }
}
